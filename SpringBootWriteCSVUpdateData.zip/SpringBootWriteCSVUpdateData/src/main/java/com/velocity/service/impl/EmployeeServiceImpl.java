package com.velocity.service.impl;

import java.io.IOException;
import java.io.Writer;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.velocity.model.Employee;
import com.velocity.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public void writeEmployeesToCsv(Writer writer) {

		List<Employee> employees = employeeRepository.findAll();
		//CSVPrinter is used to print the values in CSV format
		//CSVFormat is used to parse the input
		try (CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT)) {
			csvPrinter.printRecord("ID", "Name", "City");
			for (Employee employee : employees) {
				//2	Akshay	Pune
				csvPrinter.printRecord(employee.getId(), employee.getName(), employee.getCity());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
