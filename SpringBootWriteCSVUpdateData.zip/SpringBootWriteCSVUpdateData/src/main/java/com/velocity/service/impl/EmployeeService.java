package com.velocity.service.impl;

import java.io.Writer;

public interface EmployeeService {

	public void writeEmployeesToCsv(Writer writer);
}
