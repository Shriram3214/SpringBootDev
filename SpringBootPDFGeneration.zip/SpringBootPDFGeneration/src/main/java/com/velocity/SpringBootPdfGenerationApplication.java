package com.velocity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPdfGenerationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPdfGenerationApplication.class, args);
	}

}
