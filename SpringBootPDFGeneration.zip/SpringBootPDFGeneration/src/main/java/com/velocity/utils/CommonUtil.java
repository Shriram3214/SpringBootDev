package com.velocity.utils;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.velocity.model.Employee;

public class CommonUtil {

	public static void employeeDetailReport(HttpServletResponse response, List<Employee> employees) throws IOException {

		// Step-1- create the object of pdfWriter
		PdfWriter writer = new PdfWriter(response.getOutputStream());
		// Step-2- create the pdfdocument object and pass the pdfwriter object
		PdfDocument pdfDocument = new PdfDocument(writer);
		// Step-3- create the object of document and pass the pdfdocument object
		Document document = new Document(pdfDocument);

		try {
			//Step-4
			document.add(new Paragraph("Velocity Corporate Training Center").setBold().setPaddingLeft(200f));
			//Step-5
			Table table = new Table(new float[] { 20f, 50f, 30F });
			//Step-6
			table.setWidthPercent(100).setPadding(0).setFontSize(9);
			//Step-7
			Cell cell1 = new Cell(1, 3);
			//Step-8
			cell1.setTextAlignment(TextAlignment.CENTER);
			//Step-9
			cell1.add("Employee Details").setBold();
			//Step-10
			table.addCell(cell1);
			//Step-11- Set the header
			table.addCell(new Cell().add("Id").setBold());
			table.addCell(new Cell().add("Name").setBold());
			table.addCell(new Cell().add("City").setBold());
			//Step-12 use for each loop to iterate the data
			for (Employee emp : employees) {
				//whatever the data is present into employees
				//that will be available into emp object
				//1	pune	amit
				//2	mumbai	ramesh
				table.addCell(new Cell().add(String.valueOf(emp.getId())));
				table.addCell(new Cell().add(emp.getName()));
				table.addCell(new Cell().add(emp.getCity()));
			}
			//Step-13- add the table object into document
			document.add(table);

			document.close();
			writer.flush();
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
