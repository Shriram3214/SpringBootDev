package com.velocity.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.velocity.repository.EmployeeRespository;
import com.velocity.service.EmployeeService;
import com.velocity.utils.CommonUtil;

@RestController
public class EmployeeController {

	// inject the service and service.methodname
	@Autowired
	private EmployeeService employeeService;

	@GetMapping(value = "/pdf")
	public void employeeDetailsReport(HttpServletResponse response) throws IOException {

		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD:HH:MM:SS");
		String fileType = "attachment; filename=employee_details_" + dateFormat.format(new Date()) + ".pdf";
		response.setHeader("Content-Disposition", fileType);
		response.setContentType("application/pdf");
		CommonUtil.employeeDetailReport(response, employeeService.findAllEmployee());
	}
}
